package com.campeonato.repository;

import static org.junit.jupiter.api.Assertions.*;
import java.time.LocalDate;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.campeonato.model.Jogador;
import com.campeonato.model.Time;

@DataJpaTest
class TimeRepositoryTest {
    @Autowired 
    private TimeRepository timeRepository;
    
    @Autowired 
    private JogadorRepository jogadorRepository;

    @Test
    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    void salvarTimeDuplicado_LancaExcecao() {
        timeRepository.save(new Time("Flamengo"));
        assertThrows(DataIntegrityViolationException.class, () -> {
            timeRepository.save(new Time("Flamengo"));
        });
    }

    @Test
    @Transactional
    void salvarTimeComJogadores_PersisteRelacionamento() {
        Time time = new Time("Flamengo");
        Jogador jogador = new Jogador("Arrascaeta", LocalDate.of(1994, 6, 20), 1.72);
        jogadorRepository.save(jogador);
        
        time.adicionarJogador(jogador);
        Time salvo = timeRepository.save(time);
        
        Time buscado = timeRepository.findById(salvo.getId()).orElseThrow();
        assertEquals(1, buscado.getJogadores().size());
    }
}