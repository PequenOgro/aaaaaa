package com.campeonato.repository;

import static org.junit.jupiter.api.Assertions.*;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.transaction.annotation.Transactional;
import com.campeonato.model.Estadio;
import com.campeonato.model.Partida;
import com.campeonato.model.Time;

@DataJpaTest
@Transactional
class PartidaRepositoryTest {
    @Autowired 
    private PartidaRepository partidaRepository;
    
    @Autowired
    private EstadioRepository estadioRepository;

    @Test
    void buscarPartidasPorData_RetornaApenasDoDia() {
        Estadio estadio = new Estadio("Estádio Teste", "Cidade Teste");
        Time time1 = new Time("Time A");
        Time time2 = new Time("Time B");
        
        partidaRepository.save(new Partida(LocalDate.of(2025, 6, 10), estadio, time1, time2));
        partidaRepository.save(new Partida(LocalDate.of(2025, 6, 11), estadio, time1, time2));
        
        List<Partida> resultado = partidaRepository.findByData(LocalDate.of(2025, 6, 10));
        assertEquals(1, resultado.size());
    }

    @Test
    void buscarPartidasPorEstadio_RetornaApenasDoLocal() {
        Estadio maracana = new Estadio("Maracanã", "Rio de Janeiro");
        Estadio morumbi = new Estadio("Morumbi", "São Paulo");
        estadioRepository.save(maracana);
        estadioRepository.save(morumbi);
        
        Time time1 = new Time("Time A");
        Time time2 = new Time("Time B");
        
        partidaRepository.save(new Partida(LocalDate.now(), maracana, time1, time2));
        partidaRepository.save(new Partida(LocalDate.now(), morumbi, time1, time2));
        
        List<Partida> resultado = partidaRepository.findByEstadioNome("Maracanã");
        assertEquals(1, resultado.size());
    }
}