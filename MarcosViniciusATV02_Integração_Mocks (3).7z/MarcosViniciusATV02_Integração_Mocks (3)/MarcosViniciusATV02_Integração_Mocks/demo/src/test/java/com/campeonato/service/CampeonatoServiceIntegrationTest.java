package com.campeonato.service;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.List;

import com.campeonato.model.Estadio;
import com.campeonato.model.Partida;
import com.campeonato.model.Time;
import com.campeonato.repository.EstadioRepository;
import com.campeonato.repository.PartidaRepository;
import com.campeonato.repository.TimeRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
@Transactional
public class CampeonatoServiceIntegrationTest {

    @Autowired
    private CampeonatoService campeonatoService;

    @Autowired
    private PartidaRepository partidaRepository;

    @Autowired
    private TimeRepository timeRepository;

    @Autowired
    private EstadioRepository estadioRepository; // <--- adicionado para persistir o estádio

    @Test
    void salvarResultado_AtualizaClassificacao() {
        // Salvar times
        Time flamengo = timeRepository.save(new Time("Flamengo"));
        Time vasco = timeRepository.save(new Time("Vasco"));

        // Salvar estádio
        Estadio estadio = estadioRepository.save(new Estadio("Maracanã", "Rio de Janeiro"));

        // Salvar partida
        Partida partida = new Partida(LocalDate.now(), estadio, flamengo, vasco);
        Partida savedPartida = partidaRepository.save(partida);

        // Salvar resultado da partida
        campeonatoService.salvarResultado(savedPartida.getId(), 3, 1);

        // Obter classificação atualizada
        List<Time> classificacao = campeonatoService.getClassificacao();

        // Verificações
        assertEquals("Flamengo", classificacao.get(0).getNome());
        assertEquals(3, classificacao.get(0).getPontos()); // Vitória = 3 pontos
    }
}
