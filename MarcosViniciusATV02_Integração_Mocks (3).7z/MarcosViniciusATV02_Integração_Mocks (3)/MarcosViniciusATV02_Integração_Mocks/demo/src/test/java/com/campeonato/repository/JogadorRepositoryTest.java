package com.campeonato.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.List;

import com.campeonato.model.Jogador;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;



@DataJpaTest
public class JogadorRepositoryTest {

    @Autowired
    private JogadorRepository repository;

    @Test
    void buscarPorNome_RetornaListaCorreta() {
        repository.save(new Jogador("Neymar", LocalDate.of(1992, 2, 5), 1.75));
        repository.save(new Jogador("Gabigol", LocalDate.of(1996, 8, 30), 1.78));

        List<Jogador> resultado = repository.findByNomeContainingIgnoreCase("neymar");
        assertEquals(1, resultado.size());
    }

    @Test
    void atualizarJogador_RefleteAlteracao() {
        Jogador jogador = repository.save(new Jogador("Vini Jr", LocalDate.now(), 73.0));
        jogador.setAltura(75.5); // corrigido
        repository.save(jogador);

        Jogador atualizado = repository.findById(jogador.getId()).orElseThrow();
        assertEquals(75.5, atualizado.getAltura());
    }
}
