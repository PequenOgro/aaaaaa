package com.campeonato.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.campeonato.model.Time;
import com.campeonato.repository.TimeRepository;
import com.campeonato.dto.TimeDTO;

import jakarta.persistence.EntityNotFoundException;

@Service
public class TimeServiceImpl implements TimeService {

    @Autowired
    private TimeRepository timeRepository;

    @Autowired
    private ModelMapper mapper;

    @Override
    public List<TimeDTO> classificacao(Long campId) {
        // Exemplo simplificado: buscar todos e mapear sem lógica de pontos ainda
        List<Time> times = buscarTimesPorCampeonato(campId);
        return times.stream()
                .map(t -> mapper.map(t, TimeDTO.class))
                .collect(java.util.stream.Collectors.toList());
    }

    @Override
    public Time findByIdOrThrow(Long id) {
        return timeRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Time não encontrado: " + id));
    }




    @Override
    public List<Time> listarTimesDoCampeonato(Long campeonatoId) {
        return timeRepository.findByCampeonatoId(campeonatoId.longValue()); // se o repo usa Long
    }


    @Override
    public Time buscarTimePorId(Long timeId) {
        return findByIdOrThrow(timeId);
    }

    @Override
    public Time salvarTime(Time time) {
        return timeRepository.save(time);
    }

    @Override
    public void excluirTime(Long timeId) {
        Time t = findByIdOrThrow(timeId);
        timeRepository.delete(t);
    }

    @Override
    public Time atualizarTime(Time time) {
        // presumindo que 'time.id' já esteja preenchido
        Time existente = findByIdOrThrow(time.getId());
        existente.setNome(time.getNome());
        existente.setSede(time.getSede());
        // … atualize outros campos conforme seu modelo
        return timeRepository.save(existente);
    }

    @Override
    public List<Time> listarTodosTimes() {
        return timeRepository.findAll();
    }

    // a partir daqui, todos os métodos de busca devem existir na interface
    // ou então lançam UnsupportedOperationException até você criar a query:

    @Override
    public List<Time> buscarTimesPorNome(String nome) {
        // se não tiver um método findByNome no repo, faça:
        // return timeRepository.findAll().stream()
        // .filter(t -> t.getNome().contains(nome))
        // .toList();
        throw new UnsupportedOperationException("Implementar filtro por nome");
    }

    @Override
    public List<Time> buscarTimesPorCampeonato(Long campeonatoId) {
        return listarTimesDoCampeonato(campeonatoId);
    }

    @Override
    public List<Time> buscarTimesPorCidade(String cidade) {
        throw new UnsupportedOperationException("Implementar filtro por cidade");
    }

    @Override
    public List<Time> buscarTimesPorEstado(String estado) {
        throw new UnsupportedOperationException("Implementar filtro por estado");
    }

    @Override
    public List<Time> buscarTimesPorPais(String pais) {
        throw new UnsupportedOperationException("Implementar filtro por país");
    }

    @Override
    public List<Time> buscarTimesPorRanking(Integer ranking) {
        throw new UnsupportedOperationException("Implementar filtro por ranking");
    }

    @Override
    public List<Time> buscarTimesPorDataCriacao(String dataCriacao) {
        throw new UnsupportedOperationException("Implementar filtro por data de criação");
    }

    @Override
    public List<Time> buscarTimesPorDataAtualizacao(String dataAtualizacao) {
        throw new UnsupportedOperationException("Implementar filtro por data de atualização");
    }

    @Override
    public List<Time> buscarTimesPorStatus(String status) {
        throw new UnsupportedOperationException("Implementar filtro por status");
    }

    @Override
    public List<Time> buscarTimesPorCompeticao(String competicao) {
        throw new UnsupportedOperationException("Implementar filtro por competição");
    }

    @Override
    public List<Time> buscarTimesPorCategoria(String categoria) {
        throw new UnsupportedOperationException("Implementar filtro por categoria");
    }

    @Override
    public List<Time> buscarTimesPorTecnico(String tecnico) {
        throw new UnsupportedOperationException("Implementar filtro por técnico");
    }

    @Override
    public List<Time> buscarTimesPorNumeroJogadores(Integer numeroJogadores) {
        throw new UnsupportedOperationException("Implementar filtro por número de jogadores");
    }

    @Override
    public List<Time> buscarTimesPorMediaIdade(Double mediaIdade) {
        throw new UnsupportedOperationException("Implementar filtro por média de idade");
    }

    @Override
    public List<Time> buscarTimesPorNumeroVitorias(Integer numeroVitorias) {
        throw new UnsupportedOperationException("Implementar filtro por número de vitórias");
    }

    @Override
    public List<Time> buscarTimesPorNumeroDerrotas(Integer numeroDerrotas) {
        throw new UnsupportedOperationException("Implementar filtro por número de derrotas");
    }

    @Override
    public List<Time> buscarTimesPorNumeroEmpates(Integer numeroEmpates) {
        throw new UnsupportedOperationException("Implementar filtro por número de empates");
    }

    @Override
    public List<Time> buscarTimesPorGolsMarcados(Integer golsMarcados) {
        throw new UnsupportedOperationException("Implementar filtro por gols marcados");
    }

    @Override
    public List<Time> buscarTimesPorGolsSofridos(Integer golsSofridos) {
        throw new UnsupportedOperationException("Implementar filtro por gols sofridos");
    }

    @Override
    public List<Time> buscarTimesPorSaldoGols(Integer saldoGols) {
        throw new UnsupportedOperationException("Implementar filtro por saldo de gols");
    }

    @Override
    public List<Time> buscarTimesPorPontuacao(Integer pontuacao) {
        throw new UnsupportedOperationException("Implementar filtro por pontuação");
    }

    @Override
    public List<Time> buscarTimesPorUltimoJogo(String ultimoJogo) {
        throw new UnsupportedOperationException("Implementar filtro por último jogo");
    }

    @Override
    public List<Time> buscarTimesPorProximoJogo(String proximoJogo) {
        throw new UnsupportedOperationException("Implementar filtro por próximo jogo");
    }

    @Override
    public List<Time> buscarTimesPorHistorico(String historico) {
        throw new UnsupportedOperationException("Implementar filtro por histórico");
    }

    @Override
    public List<Time> buscarTimesPorDesempenho(String desempenho) {
        throw new UnsupportedOperationException("Implementar filtro por desempenho");
    }

    @Override
    public List<Time> buscarTimesPorParticipacaoCampeonatos(Integer participacaoCampeonatos) {
        throw new UnsupportedOperationException("Implementar filtro por participação em campeonatos");
    }
}
