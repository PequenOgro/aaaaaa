package com.campeonato.service;

import com.campeonato.model.Partida;
import java.util.List;

public interface PartidaService {
    List<Partida> listarPartidasOcorridas(Long campeonatoId);
    List<Partida> listarPartidasFuturas(Long campeonatoId);
    List<Partida> listarPartidasPorTime(Long timeId);
    List<Partida> listarPartidasPorEstadio(String estadio);
    List<Partida> listarPartidasPorData(String data);
    List<Partida> listarPartidasPorCampeonato(Long campeonatoId);
    List<Partida> listarPartidasPorPais(String pais);
    Partida save(Partida partida);
    Partida findByIdOrThrow(Long id);
}
