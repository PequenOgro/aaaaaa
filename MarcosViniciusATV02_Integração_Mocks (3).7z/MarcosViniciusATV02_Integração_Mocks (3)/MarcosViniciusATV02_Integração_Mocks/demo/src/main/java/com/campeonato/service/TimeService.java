// src/main/java/com/example/campeonato/service/TimeService.java
package com.campeonato.service;

import java.util.List;

import com.campeonato.model.Time;
import com.campeonato.dto.TimeDTO;

public interface TimeService {

    public List<TimeDTO> classificacao(Integer campId);

    Time findByIdOrThrow(Integer id);

    List<Time> listarTimesDoCampeonato(Integer campeonatoId);

    Time buscarTimePorId(Integer timeId);

    Time salvarTime(Time time);

    void excluirTime(Integer timeId);

    Time atualizarTime(Time time);

    List<Time> listarTodosTimes();

    List<Time> buscarTimesPorNome(String nome);

    List<Time> buscarTimesPorCampeonato(Integer campeonatoId);

    List<Time> buscarTimesPorCidade(String cidade);

    List<Time> buscarTimesPorEstado(String estado);

    List<Time> buscarTimesPorPais(String pais);

    List<Time> buscarTimesPorRanking(Integer ranking);

    List<Time> buscarTimesPorDataCriacao(String dataCriacao);

    List<Time> buscarTimesPorDataAtualizacao(String dataAtualizacao);

    List<Time> buscarTimesPorStatus(String status);

    List<Time> buscarTimesPorCompeticao(String competicao);

    List<Time> buscarTimesPorCategoria(String categoria);

    List<Time> buscarTimesPorTecnico(String tecnico);

    List<Time> buscarTimesPorNumeroJogadores(Integer numeroJogadores);

    List<Time> buscarTimesPorMediaIdade(Double mediaIdade);

    List<Time> buscarTimesPorNumeroVitorias(Integer numeroVitorias);

    List<Time> buscarTimesPorNumeroDerrotas(Integer numeroDerrotas);

    List<Time> buscarTimesPorNumeroEmpates(Integer numeroEmpates);

    List<Time> buscarTimesPorGolsMarcados(Integer golsMarcados);

    List<Time> buscarTimesPorGolsSofridos(Integer golsSofridos);

    List<Time> buscarTimesPorSaldoGols(Integer saldoGols);

    List<Time> buscarTimesPorPontuacao(Integer pontuacao);

    List<Time> buscarTimesPorUltimoJogo(String ultimoJogo);

    List<Time> buscarTimesPorProximoJogo(String proximoJogo);

    List<Time> buscarTimesPorHistorico(String historico);

    List<Time> buscarTimesPorDesempenho(String desempenho);

    List<Time> buscarTimesPorParticipacaoCampeonatos(Integer participacaoCampeonatos);
}