package com.campeonato;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = "com.campeonato")
@EntityScan("com.campeonato.model")
@EnableJpaRepositories("com.campeonato.repository")
public class CampeonatoApplication { 
    public static void main(String[] args) {
        SpringApplication.run(CampeonatoApplication.class, args);
    }
}

