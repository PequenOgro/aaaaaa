package com.campeonato.service;

import com.campeonato.model.Partida;
import com.campeonato.repository.PartidaRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;

@Service
public class PartidaServiceImpl implements PartidaService {

    @Autowired
    private PartidaRepository partidaRepository;

    @Override
    public List<Partida> listarPartidasOcorridas(Long campeonatoId) {
        return partidaRepository.findByCampeonatoIdAndDataBefore(campeonatoId, LocalDate.now());
    }

    @Override
    public List<Partida> listarPartidasFuturas(Long campeonatoId) {
        return partidaRepository.findByCampeonatoIdAndDataAfter(campeonatoId, LocalDate.now());
    }

    @Override
    public List<Partida> listarPartidasPorTime(Long timeId) {
        // implemente no repositório: findByMandanteIdOrVisitanteId(...)
        throw new UnsupportedOperationException("Filtro por time não implementado");
    }

    @Override
    public List<Partida> listarPartidasPorEstadio(String estadio) {
        // implemente no repositório: findByEstadioNome(...)
        throw new UnsupportedOperationException("Filtro por estádio não implementado");
    }

    @Override
    public List<Partida> listarPartidasPorData(String data) {
        try {
            LocalDate d = LocalDate.parse(data);
            return partidaRepository.findByData(d);
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("Data inválida: " + data);
        }
    }

    @Override
    public List<Partida> listarPartidasPorCampeonato(Long campeonatoId) {
        return partidaRepository.findByCampeonatoId(campeonatoId);
    }

    @Override
    public List<Partida> listarPartidasPorPais(String pais) {
        // implemente no repositório: findByEstadioPais(...)
        throw new UnsupportedOperationException("Filtro por país não implementado");
    }

    @Override
    public Partida save(Partida partida) {
        return partidaRepository.save(partida);
    }

    @Override
    public Partida findByIdOrThrow(Long id) {
        return partidaRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Partida não encontrada: " + id));
    }
}
