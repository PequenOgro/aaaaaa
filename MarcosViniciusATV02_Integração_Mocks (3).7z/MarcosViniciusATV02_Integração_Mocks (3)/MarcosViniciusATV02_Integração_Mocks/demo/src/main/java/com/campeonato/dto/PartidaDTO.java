package com.campeonato.dto;

public class PartidaDTO {

    private Integer id;
    private Integer timeAId;
    private Integer timeBId;
    private String dataHora;
    private String estadio;

    // getters e setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getTimeAId() {
        return timeAId;
    }

    public void setTimeAId(Integer timeAId) {
        this.timeAId = timeAId;
    }

    public Integer getTimeBId() {
        return timeBId;
    }

    public void setTimeBId(Integer timeBId) {
        this.timeBId = timeBId;
    }

    public String getDataHora() {
        return dataHora;
    }

    public void setDataHora(String dataHora) {
        this.dataHora = dataHora;
    }

    public String getEstadio() {
        return estadio;
    }

    public void setEstadio(String estadio) {
        this.estadio = estadio;
    }

}
