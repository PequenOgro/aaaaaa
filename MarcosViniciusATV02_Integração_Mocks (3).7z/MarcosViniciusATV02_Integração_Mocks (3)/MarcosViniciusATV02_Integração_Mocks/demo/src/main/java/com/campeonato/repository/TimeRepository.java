package com.campeonato.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.campeonato.model.Time;

@Repository
public interface TimeRepository extends JpaRepository<Time, Long> {
    @Query("SELECT t FROM Time t JOIN t.campeonatos c WHERE c.id = :campeonatoId")
    List<Time> findByCampeonatoId(@Param("campeonatoId") Long campeonatoId);
}
