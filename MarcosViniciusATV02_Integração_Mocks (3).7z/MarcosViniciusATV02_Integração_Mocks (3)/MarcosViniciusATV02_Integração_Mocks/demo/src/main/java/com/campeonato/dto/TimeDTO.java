package com.campeonato.dto;


public class TimeDTO {
    private Integer id;
    private String nome;
    private Integer estadioId;
    private Integer campeonatoId;
    private int pontos;
    private int saldoGols;

    // getters e setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getEstadioId() {
        return estadioId;
    }

    public void setEstadioId(Integer estadioId) {
        this.estadioId = estadioId;
    }

    public Integer getCampeonatoId() {
        return campeonatoId;
    }

    public void setCampeonatoId(Integer campeonatoId) {
        this.campeonatoId = campeonatoId;
    }

    public int getPontos() {
        return pontos;
    }

    public void setPontos(int pontos) {
        this.pontos = pontos;
    }

    public int getSaldoGols() {
        return saldoGols;
    }

    public void setSaldoGols(int saldoGols) {
        this.saldoGols = saldoGols;
    }

}
