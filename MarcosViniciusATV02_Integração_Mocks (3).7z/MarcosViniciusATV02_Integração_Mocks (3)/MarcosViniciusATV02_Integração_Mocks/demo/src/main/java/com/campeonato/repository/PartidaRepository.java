package com.campeonato.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.campeonato.model.Partida;
import com.campeonato.model.Time;

@Repository
public interface PartidaRepository extends JpaRepository<Partida, Long> {
        List<Partida> findByCampeonatoIdAndDataBefore(
                        @Param("campeonatoId") Long campeonatoId,
                        @Param("data") LocalDate data);

        List<Partida> findByCampeonatoIdAndDataAfter(
                        @Param("campeonatoId") Long campeonatoId,
                        @Param("data") LocalDate data);

        // Exemplo de query method para buscar partidas de um campeonato que envolvem um
        // time
        List<Partida> findByCampeonatoIdAndTimeCasaOrCampeonatoIdAndTimeFora(Long campeonatoId1, Time timeCasa,
                        Integer campeonatoId2, Time timeFora);

        // Ou, se você tem uma relação many-to-many entre Partida e Time (menos comum
        // para gols)
        // List<Partida> findByCampeonatoIdAndTimesContains(Integer campeonatoId, Time
        // time);
        // A query method que usei no exemplo (`findByCampeonatoIdAndTimesContaining`) é
        // hipotética.
        // A mais comum seria algo como:
        List<Partida> findByCampeonatoIdAndTimeCasaOrTimeFora(Long campeonatoId, Time timeCasa, Time timeFora);

        List<Partida> findByData(LocalDate data);

        List<Partida> findByCampeonatoId(Long campeonatoId);

        List<Partida> findByEstadioNome(String estadioNome);

        


}