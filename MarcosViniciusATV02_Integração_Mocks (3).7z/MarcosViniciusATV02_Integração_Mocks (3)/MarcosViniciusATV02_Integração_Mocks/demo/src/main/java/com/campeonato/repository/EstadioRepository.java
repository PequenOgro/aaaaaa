package com.campeonato.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.campeonato.model.Estadio;

@Repository
public interface EstadioRepository extends JpaRepository<Estadio, Long> {

}