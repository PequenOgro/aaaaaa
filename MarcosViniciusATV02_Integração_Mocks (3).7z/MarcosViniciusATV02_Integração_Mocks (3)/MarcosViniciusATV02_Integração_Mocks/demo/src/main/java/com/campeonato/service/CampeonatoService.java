package com.campeonato.service;

import com.campeonato.model.Time;
import java.util.List;

public interface CampeonatoService {
    void salvarResultado(Long partidaId, int golsMandante, int golsVisitante);
    List<Time> getClassificacao();
}
