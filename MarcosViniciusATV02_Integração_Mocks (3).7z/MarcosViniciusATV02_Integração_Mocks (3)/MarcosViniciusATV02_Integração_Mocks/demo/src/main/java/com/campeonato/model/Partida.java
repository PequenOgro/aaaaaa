package com.campeonato.model;

import java.time.LocalDate;

import jakarta.persistence.*;

@Entity
public class Partida {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDate data;

    @ManyToOne
    @JoinColumn(name = "campeonato_id")
    private Campeonato campeonato;

    @ManyToOne
    @JoinColumn(name = "time_mandante_id")
    private Time mandante;

    @ManyToOne
    @JoinColumn(name = "time_visitante_id")
    private Time visitante;

    @ManyToOne
    @JoinColumn(name = "estadio_id")
    private Estadio estadio;

    private Integer golsMandante;
    private Integer golsVisitante;

    public Partida() {}

    public Partida(LocalDate data, Estadio estadio, Time mandante, Time visitante) {
        this.data = data;
        this.estadio = estadio;
        this.mandante = mandante;
        this.visitante = visitante;
    }

    // Getters e Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public LocalDate getData() { return data; }
    public void setData(LocalDate data) { this.data = data; }

    public Campeonato getCampeonato() { return campeonato; }
    public void setCampeonato(Campeonato campeonato) { this.campeonato = campeonato; }

    public Time getMandante() { return mandante; }
    public void setMandante(Time mandante) { this.mandante = mandante; }

    public Time getVisitante() { return visitante; }
    public void setVisitante(Time visitante) { this.visitante = visitante; }

    public Estadio getEstadio() { return estadio; }
    public void setEstadio(Estadio estadio) { this.estadio = estadio; }

    public Integer getGolsMandante() { return golsMandante; }
    public void setGolsMandante(Integer golsMandante) { this.golsMandante = golsMandante; }

    public Integer getGolsVisitante() { return golsVisitante; }
    public void setGolsVisitante(Integer golsVisitante) { this.golsVisitante = golsVisitante; }
}
