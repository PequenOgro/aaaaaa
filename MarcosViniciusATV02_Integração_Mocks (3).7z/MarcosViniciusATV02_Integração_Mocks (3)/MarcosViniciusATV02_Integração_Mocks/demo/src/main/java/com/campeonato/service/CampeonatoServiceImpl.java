package com.campeonato.service;

import com.campeonato.model.Partida;
import com.campeonato.model.Time;
import com.campeonato.repository.PartidaRepository;
import com.campeonato.repository.TimeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CampeonatoServiceImpl implements CampeonatoService {

    @Autowired
    private PartidaRepository partidaRepository;

    @Autowired
    private TimeRepository timeRepository;

    @Override
    public void salvarResultado(Long partidaId, int golsMandante, int golsVisitante) {
        Partida partida = partidaRepository.findById(partidaId).orElseThrow();
        partida.setGolsMandante(golsMandante);
        partida.setGolsVisitante(golsVisitante);
        partidaRepository.save(partida);

        Time mandante = partida.getMandante();
        Time visitante = partida.getVisitante();

        if (golsMandante > golsVisitante) {
            mandante.setPontos(mandante.getPontos() + 3);
        } else if (golsMandante < golsVisitante) {
            visitante.setPontos(visitante.getPontos() + 3);
        } else {
            mandante.setPontos(mandante.getPontos() + 1);
            visitante.setPontos(visitante.getPontos() + 1);
        }

        timeRepository.save(mandante);
        timeRepository.save(visitante);
    }

    @Override
    public List<Time> getClassificacao() {
        // Supondo que a entidade Time tenha um campo `pontos` e o repositório suporte ordenação
        return timeRepository.findAll().stream()
            .sorted((t1, t2) -> Integer.compare(t2.getPontos(), t1.getPontos()))
            .toList();
    }
}
