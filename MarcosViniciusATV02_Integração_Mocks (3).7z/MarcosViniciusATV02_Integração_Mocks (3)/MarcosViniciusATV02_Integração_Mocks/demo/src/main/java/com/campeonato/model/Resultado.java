// src/main/java/com/example/campeonato/model/Resultado.java
package com.campeonato.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

@Entity
public class Resultado {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private Integer numGolsMandante;
    private Integer numGolsVisitante;

    @OneToOne
    @JoinColumn(name = "partida_id")
    private Partida partida;

    public int getPontuacaoMandante() {
        return numGolsMandante > numGolsVisitante ? 3
                : numGolsMandante.equals(numGolsVisitante) ? 1 : 0;
    }

    public int getPontuacaoVisitante() {
        return numGolsVisitante > numGolsMandante ? 3
                : numGolsVisitante.equals(numGolsMandante) ? 1 : 0;
    }

    public boolean jogoSaiuEmpatado() {
        return numGolsMandante.equals(numGolsVisitante);
    }

    // getters/setters

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getNumGolsMandante() {
        return numGolsMandante;
    }

    public void setNumGolsMandante(Integer numGolsMandante) {
        this.numGolsMandante = numGolsMandante;
    }

    public Integer getNumGolsVisitante() {
        return numGolsVisitante;
    }

    public void setNumGolsVisitante(Integer numGolsVisitante) {
        this.numGolsVisitante = numGolsVisitante;
    }

    public Partida getPartida() {
        return partida;
    }

    public void setPartida(Partida partida) {
        this.partida = partida;
    }
}